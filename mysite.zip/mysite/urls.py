"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from cms import views as cms
from main import views as main
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [

    path('admin/', admin.site.urls),
    #CMS URLS
    path('admin-login',cms.AdminLogin),
    path('admin-logout',cms.AdminLogout),
    path('add-type', cms.AddType),
    path('update-type/<int:id>', cms.UpdateType),
    path('add-categories',cms.AddCategories),
    path('update-category/<int:id>', cms.UpdateCategories),
    path('add-product',cms.AddProduct),
    path('update-product/<int:id>', cms.UpdateProduct),
    path('add-attribute',cms.AddAttribute),
    path('index',cms.Index),
    path('view-product',cms.GetProducts),
    path('view-category',cms.GetCategories),
    path('view-type',cms.GetTypes),
    path('view-attribute/<int:id>',cms.GetAttributes),
    path('add-attribute/<int:id>',cms.AddAttribute),
    path('delete-type/<int:id>',cms.DeleteType),
    path('delete-product/<int:id>',cms.DeleteProduct),
    path('delete-category/<int:id>',cms.DeleteCategory),

    # FrontEnd URLS
    path('home-2', main.Home2),
    path('shop', main.Products),
    path('userlogin',main.Login),
    path('logout',main.Logout),
    path('userregister',main.Register),
]

urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)

 
